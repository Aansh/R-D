/* Skelix by Xiaoming Mo (xiaoming.mo@skelix.org)
 * Licence: GPLv2 */
#ifndef KB_H
#define KB_H

void kb_install(void);

#endif
